package com.example.myapplication.ui.Purchase;

import androidx.lifecycle.ViewModel;

public class PurchaseViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}